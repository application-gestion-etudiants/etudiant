package com.example.etudiants;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtudiantsApplicationTests {

	@Test
	void contextLoads() {
	}

}
